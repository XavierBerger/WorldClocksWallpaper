Program: ESBDates v2.1.0 Released: 8 October 2000

Purpose: Freeware Date/Time Routine Collection for Delphi.

More Info: See ESBDates.TXT

Installation: unzip into a dir of your choice. 
Place PAS file in Library Path. 

Status: Freeware, freely distributable

Contact: Glenn Crouch mailto:support@esbconsult.com.au

There is a support Conference available at:
http://wb1.e-fora.net:8080/~ESB

Note: The document Calendar23.txt has been included with
permission from the author.
